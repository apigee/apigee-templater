print("hello world!");

context.proxyResponse.content += "hello world!";